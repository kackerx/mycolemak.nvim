package main

import (
	"fmt"
	"testing"
)

func TestGO(t *testing.T) {
	fmt.Println(1)
	println(2)
}

func TestTT(t *testing.T) {
	fmt.Println(1)
	fmt.Println(2)
}
