def main():
    print("kacker")
    print("kacker")

    requests.get()
