return {
    {
        "kdheepak/lazygit.nvim",
        event = "VeryLazy", 
        enabled = false, 
        -- optional for floating window border decoration
        dependencies = {
            "nvim-lua/plenary.nvim",
        },
    },
}
