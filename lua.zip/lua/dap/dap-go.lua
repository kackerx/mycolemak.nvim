local dap = require('dap')

-- 获取当前光标所在位置的函数名称
local function get_function_name()
    local pos = vim.fn.getpos(".")
    local line = vim.fn.getline(pos[2])
    local start_col, end_col = string.find(line, "func Test")
    if start_col == nil then
        return nil
    end
    local name = string.match(line:sub(end_col + 1), "^%a+")
    return name
end

-- 生成 DAP 配置文件
local function generate_dap_config()
    local function_name = get_function_name()
    if function_name == nil then
        return nil
    end
    return {
        type = "go",
        name = "Debug test function",
        request = "launch",
        mode = "test",
        cwd = "${workspaceFolder}",
        program = "${file}",
        args = { "-test.run", "^" .. function_name .. "$" },
    }
end


dap.adapters.go = function(callback, config)
    print(generate_dap_config())
    local stdout = vim.loop.new_pipe(false)
    local handle
    local pid_or_err
    local port = 38697
    local opts = {
        stdio = { nil, stdout },
        args = { "dap", "--check-go-version=false", "--listen=127.0.0.1:" .. port, "--log-dest=3" },
        detached = true
    }
    handle, pid_or_err = vim.loop.spawn("dlv", opts, function(code)
        stdout:close()
        handle:close()
        if code ~= 0 then
            print('dlv exited with code', code)
        end
    end)
    assert(handle, 'Error running dlv: ' .. tostring(pid_or_err))
    stdout:read_start(function(err, chunk)
        assert(not err, err)
        if chunk then
            vim.schedule(function()
                require('dap.repl').append(chunk)
            end)
        end
    end)
    -- Wait for delve to start
    vim.defer_fn(
        function()
            callback({ type = "server", host = "127.0.0.1", port = port })
        end,
        300)
end

-- https://github.com/go-delve/delve/blob/master/Documentation/usage/dlv_dap.md
dap.configurations.go = {
    {
        type = "go",
        name = "Debug",
        request = "launch",
        cwd = '${workspaceFolder}',
        program = "${file}",
        output = "console",
        args = function()
            local input = vim.fn.input("Input args: ")
            return require("dap.dap-util").str2argtable(input)
        end,
    },
    {
        type = "go",
        name = "Debug test", -- configuration for debugging test files
        request = "launch",
        mode = "test",
        cwd = '${workspaceFolder}',
        program = "${file}"
    },
    -- works with go.mod packages and sub packages
    {
        type = "go",
        name = "Debug test (go.mod)",
        request = "launch",
        mode = "test",
        cwd = '${workspaceFolder}',
        program = "./${relativeFileDirname}"
    },
    generate_dap_config()
}
